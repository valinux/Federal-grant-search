from flask import Flask, render_template, request
import sqlite3
import json
import urllib.parse
import re

app = Flask(__name__)
db_path = 'output.db'  # Change this to your actual database file

def build_graph_url(serialized_graph, filer_name):
    """
    Cleans and encodes the serialized_graph and builds the final URL.
    Uses filer_name to create a dynamic title and return_url.
    """
    # Clean the serialized graph
    cleaned_graph = re.sub(r'[\r\n]+', '', serialized_graph).strip()
    encoded_graph = urllib.parse.quote(cleaned_graph, safe='')

    # Build dynamic title and return_url
    title_text = f"Charity graph\nDisplaying {filer_name}"
    encoded_title = urllib.parse.quote(title_text, safe='')
    dynamic_return_url = f"https://datarepublican.com/officers/?nonprofit_kw={urllib.parse.quote(filer_name)}"
    encoded_return_url = urllib.parse.quote(dynamic_return_url, safe='')

    # Construct the final URL for the custom graph
    final_url = (
        f"https://datarepublican.com/expose/?custom_graph={encoded_graph}"
        f"&title={encoded_title}"
        f"&return_url={encoded_return_url}"
    )
    return final_url

def build_grants_url(serialized_graph):
    """
    Cleans and encodes the serialized_graph and builds the URL for total grants.
    """
    cleaned_graph = re.sub(r'[\r\n]+', '', serialized_graph).strip()
    encoded_graph = urllib.parse.quote(cleaned_graph, safe='')
    final_url = f"https://datarepublican.com/expose/?eins={encoded_graph}"
    return final_url

def extract_official_names_from_json(json_str):
    """
    Extracts a list of official names from a JSON string.
    """
    try:
        officials = json.loads(json_str)
        names = []
        if isinstance(officials, list):
            for official in officials:
                if isinstance(official, dict) and "n" in official:
                    names.append(official["n"])
        return names
    except Exception:
        return []

def search_filings(query):
    """
    Searches the filings database for a query in either filer_ein, filer_name,
    or in the officials_json content.
    """
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row  # enables dict-like access to rows
    cursor = conn.cursor()

    like_query = f"%{query}%"
    # Search in filer_ein and filer_name using LIKE
    sql = """
    SELECT * FROM filings
    WHERE filer_ein LIKE ? OR filer_name LIKE ?
    """
    cursor.execute(sql, (like_query, like_query))
    sql_matches = [dict(row) for row in cursor.fetchall()]

    # Additionally, check the officials_json field for matching names
    cursor.execute("SELECT * FROM filings")
    all_rows = [dict(row) for row in cursor.fetchall()]
    officials_matches = []
    for row in all_rows:
        officials_json = row.get("officials_json", "")
        if not officials_json:
            continue
        names = extract_official_names_from_json(officials_json)
        for name in names:
            if query.lower() in name.lower():
                officials_matches.append(row)
                break

    # Combine results uniquely using filer_ein as key
    combined = {row["filer_ein"]: row for row in sql_matches + officials_matches}
    conn.close()
    return list(combined.values())

@app.route('/', methods=['GET', 'POST'])
def index():
    results = []
    query = ""
    if request.method == 'POST':
        query = request.form.get('query', '')
        results = search_filings(query)
        
        # Process each result row
        for row in results:
            # Parse officials_json (if it exists)
            if row.get('officials_json'):
                try:
                    row['officials_json'] = json.loads(row['officials_json'])
                except Exception:
                    row['officials_json'] = []
            
            # Build URLs for the custom graph and total grants if serialized_graph exists
            if row.get('serialized_graph') and row['serialized_graph'].strip():
                row['graph_url'] = build_graph_url(row['serialized_graph'], row['filer_name'])
                row['grants_url'] = build_grants_url(row['serialized_graph'])
            else:
                row['graph_url'] = None
                row['grants_url'] = None
            
            # --- Add ProPublica links ---
            # First link: uses filer_ein only
            if row.get('filer_ein'):
                row['propublica_link'] = f"https://projects.propublica.org/nonprofits/organizations/{row['filer_ein']}"
            else:
                row['propublica_link'] = None
            
            # Second link: uses filer_ein and xml_name (ensure xml_name exists and is not empty)
            if row.get('xml_name') and str(row['xml_name']).strip():
                row['propublica_link_with_xml'] = f"https://projects.propublica.org/nonprofits/organizations/{row['filer_ein']}/{row['xml_name']}/full"
            else:
                row['propublica_link_with_xml'] = None

    return render_template('index.html', results=results, query=query)

if __name__ == '__main__':
    app.run(debug=True, port=8080)
