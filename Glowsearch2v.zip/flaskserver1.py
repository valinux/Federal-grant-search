from flask import Flask, render_template, request
import sqlite3
import json

app = Flask(__name__)
db_path = 'output.db'  # Change this to your actual database file

def extract_official_names_from_json(json_str):
    """
    Extracts a list of official names from the JSON string.
    Each official is a dict with keys:
      - "n": the official's name
      - "t": the official's title
    """
    try:
        officials = json.loads(json_str)
        names = []
        if isinstance(officials, list):
            for official in officials:
                if isinstance(official, dict) and "n" in official:
                    names.append(official["n"])
        return names
    except Exception:
        return []

def search_filings(query):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row  # enables dict-like access to rows
    cursor = conn.cursor()

    like_query = f"%{query}%"
    # Search in filer_ein and filer_name using LIKE
    sql = """
    SELECT * FROM filings
    WHERE filer_ein LIKE ? OR filer_name LIKE ?
    """
    cursor.execute(sql, (like_query, like_query))
    sql_matches = [dict(row) for row in cursor.fetchall()]  # Convert rows to dicts

    # Also scan through all rows to check officials_json for the query
    cursor.execute("SELECT * FROM filings")
    all_rows = [dict(row) for row in cursor.fetchall()]
    officials_matches = []
    for row in all_rows:
        # Use the "in" operator on row keys instead of .get()
        officials_json = row["officials_json"] if "officials_json" in row else ""
        if not officials_json:
            continue
        names = extract_official_names_from_json(officials_json)
        for name in names:
            if query.lower() in name.lower():
                officials_matches.append(row)
                break  # Found a match in this row; no need to check further

    # Combine results using filer_ein as a unique key to avoid duplicates
    combined = {row["filer_ein"]: row for row in sql_matches + officials_matches}
    conn.close()
    return list(combined.values())

@app.route('/', methods=['GET', 'POST'])
def index():
    results = []
    query = ""
    if request.method == 'POST':
        query = request.form.get('query', '')
        results = search_filings(query)
        
        # Parse the officials_json field to convert from JSON string to list.
        for row in results:
            if row.get('officials_json'):
                try:
                    row['officials_json'] = json.loads(row['officials_json'])
                except Exception:
                    row['officials_json'] = []
    
    return render_template('index.html', results=results, query=query)

if __name__ == '__main__':
    app.run(debug=True, port=8080)

